git add .
git commit -m "JSP study"
git push
git add .
git commit -m "home"
git push